# Impact

Impact is an HTML5 Game Engine. More info & documentation: http://impactjs.com/

Various example games to get you started are available on http://impactjs.com/download

Impact is published under the [MIT Open Source License](http://opensource.org/licenses/mit-license.php). Note that Weltmeister (Impact's level editor) uses jQuery which comes with its own license.
